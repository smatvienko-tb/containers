ALTER TABLE utl_file.utl_file_dir ADD COLUMN dirname text UNIQUE;
